http://127.0.0.1:5000/camino_formulario
http://127.0.0.1:5000/camino
http://127.0.0.1:5000/grafo